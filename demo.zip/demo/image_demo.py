# # Copyright (c) OpenMMLab. All rights reserved.
# from argparse import ArgumentParser

# from mmdet.apis import inference_detector, init_detector, show_result_pyplot

# import mmrotate  # noqa: F401


# def parse_args():
#     parser = ArgumentParser()
#     parser.add_argument('img', help='Image file')
#     parser.add_argument('config', help='Config file')
#     parser.add_argument('checkpoint', help='Checkpoint file')
#     parser.add_argument('--out-file', default=None, help='Path to output file')
#     parser.add_argument(
#         '--device', default='cuda:0', help='Device used for inference')
#     parser.add_argument(
#         '--palette',
#         default='sar',      ########################   default='dota',
#         choices=['dota', 'sar', 'hrsc', 'hrsc_classwise', 'random'],
#         help='Color palette used for visualization')
#     parser.add_argument(
#         '--score-thr', type=float, default=0.3, help='bbox score threshold')
#     args = parser.parse_args()
#     return args


# def main(args):
#     # build the model from a config file and a checkpoint file
#     model = init_detector(args.config, args.checkpoint, device=args.device)
#     # test a single image
#     result = inference_detector(model, args.img)
#     # show the results
#     show_result_pyplot(
#         model,
#         args.img,
#         result,
#         palette=args.palette,
#         score_thr=args.score_thr,
#         out_file=args.out_file)


# if __name__ == '__main__':
#     args = parse_args()
#     main(args)



##############################################################################我的
# import cv2
# import numpy as np

#     # Copyright (c) OpenMMLab. All rights reserved.
from argparse import ArgumentParser

# from mmdet.apis import inference_detector, init_detector, show_result_pyplot

import mmrotate  # noqa: F401
# 在文件顶部加入这些 import（与原有 import 并列）
import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from mmdet.apis import inference_detector, init_detector


import matplotlib
matplotlib.use('Agg')  # 如果在无显示环境下运行（比如服务器），用 Agg 后端保存图片
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def parse_args():
    parser = ArgumentParser()
    parser.add_argument('img', help='Image file')
    parser.add_argument('config', help='Config file')
    parser.add_argument('checkpoint', help='Checkpoint file')
    parser.add_argument('--out-file', default=None, help='Path to output file')
    parser.add_argument(
        '--device', default='cuda:0', help='Device used for inference')
    parser.add_argument(
        '--palette',
        default='sar',      ########################   default='dota',
        choices=['dota', 'sar', 'hrsc', 'hrsc_classwise', 'random'],
        help='Color palette used for visualization')
    parser.add_argument(
        '--score-thr', type=float, default=0.3, help='bbox score threshold')
    args = parser.parse_args()
    return args



# def draw_and_save_matplotlib(model,                     ########可以用但是尖尖的角
#                              img_path,
#                              result,
#                              out_file=None,
#                              score_thr=0.3,
#                              text_rgb=(0.0, 1.0, 0.0),   # green
#                              edge_rgb=(0.0, 1.0, 0.0),
#                              linewidth=2):

#     import cv2
#     import numpy as np
#     import matplotlib
#     matplotlib.use('Agg')
#     import matplotlib.pyplot as plt
#     import matplotlib.patches as patches

#     FONT_SCALE = 0.32
#     MIN_FS = 6
#     MAX_FS = 26

#     # 背景黑色配置（新）
#     BBOX_PAD = 0.08
#     BBOX_ALPHA = 1.0  # 完全不透明黑色

#     bgr = cv2.imread(img_path, cv2.IMREAD_COLOR)
#     img = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
#     h_img, w_img = img.shape[:2]

#     CLASSES = getattr(model, 'CLASSES', None)

#     if isinstance(result, tuple):
#         bbox_result = result[0]
#     else:
#         bbox_result = result

#     fig_w = max(6, w_img / 100.0)
#     fig_h = max(4, h_img / 100.0)
#     fig, ax = plt.subplots(1, figsize=(fig_w, fig_h), dpi=100)
#     ax.imshow(img)
#     ax.axis('off')

#     def compute_fontsize_from_box(w_box, h_box):
#         base = float(max(1.0, min(w_box, h_box)))
#         fs = FONT_SCALE * base
#         return float(max(MIN_FS, min(MAX_FS, fs)))

#     font_family = 'DejaVu Sans'

#     for cls_id, bboxes in enumerate(bbox_result):
#         if bboxes is None or len(bboxes) == 0:
#             continue
#         bboxes = np.asarray(bboxes)

#         for row in bboxes:
#             score = float(row[-1])
#             if score < score_thr:
#                 continue

#             label = CLASSES[cls_id] if CLASSES is not None else f'class{cls_id}'
#             text = f'{label}|{score:.2f}'

#             coords = row[:-1].astype(float)

#             # HBB
#             if coords.size == 4:
#                 x1, y1, x2, y2 = coords
#                 w_box = x2 - x1
#                 h_box = y2 - y1
#                 rect = patches.Rectangle((x1, y1), w_box, h_box,
#                                          linewidth=linewidth, edgecolor=edge_rgb, facecolor='none')
#                 ax.add_patch(rect)
#                 cx = x1 + w_box / 2
#                 cy = y1 + h_box / 2
#                 fontsize = compute_fontsize_from_box(w_box, h_box)

#             # OBB
#             elif coords.size >= 5:
#                 cx, cy, w_box, h_box, angle = coords[:5]
#                 angle_deg = angle * 180 / np.pi if abs(angle) < 10 else angle
#                 rect_cv = ((float(cx), float(cy)), (float(w_box), float(h_box)), float(angle_deg))
#                 box_pts = cv2.boxPoints(rect_cv)
#                 poly = patches.Polygon(box_pts, closed=True,
#                                        linewidth=linewidth, edgecolor=edge_rgb, facecolor='none')
#                 ax.add_patch(poly)
#                 fontsize = compute_fontsize_from_box(w_box, h_box)

#             # polygon fallback
#             else:
#                 xs = coords[0::2]
#                 ys = coords[1::2]
#                 x1, y1 = np.min(xs), np.min(ys)
#                 x2, y2 = np.max(xs), np.max(ys)
#                 w_box = x2 - x1
#                 h_box = y2 - y1
#                 rect = patches.Rectangle((x1, y1), w_box, h_box,
#                                          linewidth=linewidth, edgecolor=edge_rgb, facecolor='none')
#                 ax.add_patch(rect)
#                 cx = x1 + w_box / 2
#                 cy = y1 + h_box / 2
#                 fontsize = compute_fontsize_from_box(w_box, h_box)

#             # 🔥 这里是你需要的纯黑背景（替换版本）
#             bbox_props = dict(
#                 boxstyle='square,pad={:.3f}'.format(BBOX_PAD),
#                 facecolor='black',
#                 edgecolor='none',
#                 alpha=BBOX_ALPHA
#             )

#             ax.text(cx, cy, text,
#                     fontsize=fontsize,
#                     color=text_rgb,
#                     ha='left', va='top',
#                     family=font_family,
#                     weight='normal',
#                     bbox=bbox_props)

#     plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
#     if out_file:
#         plt.savefig(out_file, dpi=200, bbox_inches='tight', pad_inches=0)
#         plt.close(fig)
#     else:
#         plt.show()
#         plt.close(fig)



# def main(args):
#     model = init_detector(args.config, args.checkpoint, device=args.device)
#     result = inference_detector(model, args.img)
#     # 使用我们自定义的绘图，全部文本和 box 颜色统一绿色
#     # draw_and_save_result(
#     #     model,
#     #     args.img,
#     #     result,
#     #     out_file=args.out_file,
#     #     score_thr=args.score_thr,
#     #     text_color=(0,255,0),   # BGR green
#     #     bbox_color=(0,255,0)
#     # )
#     # 调用自定义 matplotlib 绘制函数（文本左上角在框中心，绿色）
#     draw_and_save_matplotlib(
#         model,
#         args.img,
#         result,
#         out_file=args.out_file,
#         score_thr=args.score_thr,
#         text_rgb=(0.0, 1.0, 0.0),   # green in matplotlib RGB
#         edge_rgb=(0.0, 1.0, 0.0),
#         linewidth=2
#     )


def draw_and_save_matplotlib(model,
                             img_path,
                             result,
                             out_file=None,
                             score_thr=0.3,
                             text_rgb=(0.0, 1.0, 0.0),   # green
                             edge_rgb=(0.0, 1.0, 0.0),
                             linewidth=2):
    """
    Matplotlib drawing:
    - Text top-left at detection box center (so text extends to the right/down from center)
    - Font weight normal (thin), size scales with box short side
    - Box corners use joinstyle='round' to create rounded corners
    Supports HBB (x1,y1,x2,y2), OBB (cx,cy,w,h,angle), and polygon fallbacks.
    """
    # params for font sizing and style
    FONT_SCALE = 0.32
    MIN_FS = 6
    MAX_FS = 26

    # bbox text background (pure black, no edge, fully opaque)
    BBOX_PAD = 0.08
    BBOX_ALPHA = 1.0

    # load image (BGR -> RGB)
    bgr = cv2.imread(img_path, cv2.IMREAD_COLOR)
    if bgr is None:
        raise RuntimeError(f'Failed to read image: {img_path}')
    img = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    h_img, w_img = img.shape[:2]

    CLASSES = getattr(model, 'CLASSES', None)

    # normalize result
    if isinstance(result, tuple):
        bbox_result = result[0]
    else:
        bbox_result = result

    # create figure sized to the image (keeps text sizing coherent)
    fig_w = max(6, w_img / 100.0)
    fig_h = max(4, h_img / 100.0)
    fig, ax = plt.subplots(1, figsize=(fig_w, fig_h), dpi=100)
    ax.imshow(img)
    ax.axis('off')

    def compute_fontsize_from_box(w_box, h_box):
        base = float(max(1.0, min(w_box, h_box)))  # use short side
        fs = FONT_SCALE * base
        return float(max(MIN_FS, min(MAX_FS, fs)))

    font_family = 'DejaVu Sans'  # 常见且细体外观良好

    for cls_id, bboxes in enumerate(bbox_result):
        if bboxes is None or len(bboxes) == 0:
            continue
        bboxes = np.asarray(bboxes)

        for row in bboxes:
            score = float(row[-1])
            if score < score_thr:
                continue

            label = CLASSES[cls_id] if CLASSES is not None else f'class{cls_id}'
            text = f'{label}|{score:.2f}'

            coords = row[:-1].astype(float)

            # --- HBB: convert to 4 corner points and draw as polygon with round joins ---
            if coords.size == 4:
                x1, y1, x2, y2 = coords
                # ensure valid box
                x1, y1, x2, y2 = float(x1), float(y1), float(x2), float(y2)
                pts = np.array([[x1, y1],
                                [x2, y1],
                                [x2, y2],
                                [x1, y2]])
                w_box = max(1.0, x2 - x1)
                h_box = max(1.0, y2 - y1)
                # use Polygon with joinstyle='round' to round the corners
                poly = patches.Polygon(pts, closed=True, linewidth=linewidth,
                                       edgecolor=edge_rgb, facecolor='none',
                                       joinstyle='round')
                ax.add_patch(poly)
                cx = x1 + w_box / 2.0
                cy = y1 + h_box / 2.0
                fontsize = compute_fontsize_from_box(w_box, h_box)

            # --- OBB: rotation box, get 4 pts from cv2.boxPoints, draw polygon with round joins ---
            elif coords.size >= 5:
                cx, cy, w_box, h_box = coords[:4]
                angle = coords[4]
                # detect radians vs degrees
                angle_deg = float(angle)
                if abs(angle_deg) <= 2 * np.pi + 1e-6:
                    angle_deg = angle_deg * 180.0 / np.pi
                rect_cv = ((float(cx), float(cy)), (float(w_box), float(h_box)), float(angle_deg))
                box_pts = cv2.boxPoints(rect_cv)  # 4x2
                poly = patches.Polygon(box_pts, closed=True, linewidth=linewidth,
                                       edgecolor=edge_rgb, facecolor='none',
                                       joinstyle='round')
                ax.add_patch(poly)
                fontsize = compute_fontsize_from_box(w_box, h_box)
                cx = float(cx)
                cy = float(cy)

            # --- fallback polygon: draw polygon from given points and round joins ---
            else:
                xs = coords[0::2]
                ys = coords[1::2]
                if len(xs) == 0 or len(ys) == 0:
                    continue
                x1, y1 = float(np.min(xs)), float(np.min(ys))
                x2, y2 = float(np.max(xs)), float(np.max(ys))
                w_box = max(1.0, x2 - x1)
                h_box = max(1.0, y2 - y1)
                pts = np.vstack([coords.reshape(-1, 2)])
                poly = patches.Polygon(pts, closed=True, linewidth=linewidth,
                                       edgecolor=edge_rgb, facecolor='none',
                                       joinstyle='round')
                ax.add_patch(poly)
                cx = x1 + w_box / 2.0
                cy = y1 + h_box / 2.0
                fontsize = compute_fontsize_from_box(w_box, h_box)

            # --- Text: top-left at (cx,cy) with black background (opaque) ---
            bbox_props = dict(
                boxstyle='square,pad={:.3f}'.format(BBOX_PAD),
                facecolor='black',
                edgecolor='none',
                alpha=BBOX_ALPHA
            )

            ax.text(cx, cy, text,
                    fontsize=fontsize,
                    color=text_rgb,
                    ha='left', va='top',
                    family=font_family,
                    weight='normal',
                    bbox=bbox_props)

    plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
    if out_file:
        plt.savefig(out_file, dpi=200, bbox_inches='tight', pad_inches=0)
        plt.close(fig)
        print(f'Saved visualization to {out_file}')
    else:
        plt.show()
        plt.close(fig)


def main(args):
    """
    Complete main: init model, run inference, draw/save with matplotlib visualizer (rounded-corner boxes).
    args must provide: img, config, checkpoint, out_file (optional), device, score_thr
    """
    # initialize model (no change to installed mmrotate/mmdet)
    model = init_detector(args.config, args.checkpoint, device=args.device)

    # inference
    result = inference_detector(model, args.img)

    # draw/save
    draw_and_save_matplotlib(
        model,
        args.img,
        result,
        out_file=args.out_file,
        score_thr=args.score_thr,
        text_rgb=(0.0, 1.0, 0.0),
        edge_rgb=(0.0, 1.0, 0.0),
        linewidth=2
    )






if __name__ == '__main__':
    args = parse_args()
    main(args)

