# Copyright (c) OpenMMLab. All rights reserved.
from .utils import _check_fields

__all__ = ['_check_fields']
